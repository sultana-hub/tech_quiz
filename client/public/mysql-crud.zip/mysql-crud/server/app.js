
require("dotenv").config();
const express = require("express");
const db = require("./app/dbCon"); 


const app = express();
 db();

app.use(express.json());



// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});
